MERN Stack Blog Application
